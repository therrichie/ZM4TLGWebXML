/**
 * 
 */
/**
 * 
 */
module JSONParseZM4TLG {
	requires json.simple;
}