package hu.domparse.zm4tlg;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory; 

import javax.xml.transform.*; // Általános transzformációs műveletekhez (DOM → más formátum pl. XML fájl)
import javax.xml.transform.dom.DOMSource; // A DOM-dokumentum lesz a transzformáció bemenete
import javax.xml.transform.stream.StreamResult; // A transzformáció kimenete – fájlba vagy konzolra való íráshoz


import org.w3c.dom.*;

public class DOMModifyZM4TLG {

    public static void main(String[] args) {
        try {
            // XML fájl beolvasása
            File xmlFile = new File("XMLZM4TLG.xml");
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            System.out.println("Módosítások megtörténtek:");

            // 1. Főszervező nevének módosítása (Kiss Dóra-ról Nagyné Kiss Dóra-ra)
            NodeList fszList = doc.getElementsByTagName("foszervezo");
            for (int i = 0; i < fszList.getLength(); i++) {
                Element fsz = (Element) fszList.item(i);
                String nev = fsz.getElementsByTagName("nev").item(0).getTextContent();
                if (nev.equals("Kiss Dóra")) {
                    fsz.getElementsByTagName("nev").item(0).setTextContent("Nagyné Kiss Dóra");
                    System.out.println(" - Főszervező neve módosítva: Kiss Dóra -> Nagyné Kiss Dóra");
                }
            }

            // 2. Szervező telefonszámának módosítása ("sz1" kódú szervezőnek módosítja a telszámát)
            NodeList szervezok = doc.getElementsByTagName("szervezo");

            for (int i = 0; i < szervezok.getLength(); i++) {
                Element sz = (Element) szervezok.item(i);
                String szkod = sz.getAttribute("szkod");

                if (szkod.equals("sz1")) {
                    // Szervező nevének kiolvasása
                    String nev = sz.getElementsByTagName("nev").item(0).getTextContent();
                    // Telefonszám módosítása
                    Element kontakt = (Element) sz.getElementsByTagName("kontakt").item(0);
                    kontakt.getElementsByTagName("tel").item(0).setTextContent("+36207878787");
                    // Konzolra kiírás névvel együtt
                    System.out.println(" - Szervező: " + nev + " új telefonszáma: +36207878787 - módosítva");
                }
            }


            // 3. Technikusok e-mail címe módosítása – csak akik a Szegedi (kp3) központban dolgoznak
            NodeList techList = doc.getElementsByTagName("technikus");

            for (int i = 0; i < techList.getLength(); i++) {
                Element tech = (Element) techList.item(i);
                String kp_t = tech.getAttribute("kp_t"); // központkód

                if (kp_t.equals("kp3")) {
                    // Név lekérdezése a kiíráshoz
                    String nev = tech.getElementsByTagName("nev").item(0).getTextContent();

                    // Kontakt blokk és e-mail cím módosítása
                    Element kontakt = (Element) tech.getElementsByTagName("kontakt").item(0);
                    kontakt.getElementsByTagName("mail").item(0).setTextContent("technikus.szeged@example.com");

                    // Konzolra kiírás
                    System.out.println(" - Technikus: " + nev + " e-mail módosítva lett:  technikus.szeged@example.com");
                }
            }


            // 4. Résztvevő cím utcanév módosítása – szűkített feltétel szerint (Kárász utca -> Halász utca)
            NodeList rtList = doc.getElementsByTagName("resztvevo");

            for (int i = 0; i < rtList.getLength(); i++) {
                Element rt = (Element) rtList.item(i);

                String nev = rt.getElementsByTagName("nev").item(0).getTextContent();

                Element cim = (Element) rt.getElementsByTagName("cim").item(0);
                String varos = cim.getElementsByTagName("varos").item(0).getTextContent();
                String utca = cim.getElementsByTagName("utca").item(0).getTextContent();
                String hazszam = cim.getElementsByTagName("hazszam").item(0).getTextContent();

                // Csak ha minden feltétel egyezik
                if (nev.equals("Lukács András") && varos.equals("Szeged") && utca.equals("Kárász utca") && hazszam.equals("19")) {
                    cim.getElementsByTagName("utca").item(0).setTextContent("Halász utca");

                    System.out.println(" - Résztvevő: " + nev + " címének módosítása (Szeged, Kárász utca 19 -> Halász utca 19) - megtörtént" );
                }
            }


            // 5. Eseménynevek módosítása globálisan (minden "Innovációs Workshop" esemény legyen "AI training Workshop")
            NodeList esemenyek = doc.getElementsByTagName("esemeny");
            for (int i = 0; i < esemenyek.getLength(); i++) {
                Element es = (Element) esemenyek.item(i);
                String jelenlegi = es.getTextContent();
                if (jelenlegi.equals("Innovációs Workshop")) {
                    es.setTextContent("AI training Workshop");
                    System.out.println(" - Esemény nevének módosítása megtörtént: Innovációs Workshop -> AI training Workshop");
                }
            }

            
            
       
            // Módosított XML kiírása a konzolra 
            System.out.println("\nA Módosított XML teljes tartalma:");

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "no"); // tagolás

            DOMSource source = new DOMSource(doc);
            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);

            
	         // Módosított xml kimentése fájlba is (nem feladat követelmény)
	         StreamResult fileResult = new StreamResult(new File("XMLModifiedZM4TLG.xml"));
	         transformer.transform(source, fileResult); //mentés

         
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
