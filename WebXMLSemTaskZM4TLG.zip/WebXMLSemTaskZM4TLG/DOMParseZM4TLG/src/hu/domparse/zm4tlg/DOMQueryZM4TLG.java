package hu.domparse.zm4tlg;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;

public class DOMQueryZM4TLG {

    public static void main(String[] args) {
        try {
            // XML fájl beolvasása
            File inputFile = new File("XMLZM4TLG.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            // 1. Lekérdezi az összes főszervező nevét és listázza a konzolra
            System.out.println("1.Az összes főszervező neve:");
            NodeList fszList = doc.getElementsByTagName("foszervezo");
            for (int i = 0; i < fszList.getLength(); i++) {
                Element fsz = (Element) fszList.item(i);
                String nev = fsz.getElementsByTagName("nev").item(0).getTextContent();
                System.out.println("- " + nev);
            }
            
            // 2. Lekérdezi a Szegedi központhoz (kp3-hoz) tartozó technikusokat és elérhetőségeiket, majd listázza konzolra
            System.out.println("\n2. A Szegedi Konferenciaközpontban dolgozó technikusok elérhetőségei:");
            NodeList technikusok = doc.getElementsByTagName("technikus");
            for (int i = 0; i < technikusok.getLength(); i++) {
                Element tech = (Element) technikusok.item(i);
                if (tech.getAttribute("kp_t").equals("kp3")) {
                    String nev = tech.getElementsByTagName("nev").item(0).getTextContent();
                    Element kontakt = (Element) tech.getElementsByTagName("kontakt").item(0);
                    String tel = kontakt.getElementsByTagName("tel").item(0).getTextContent();
                    String mail = kontakt.getElementsByTagName("mail").item(0).getTextContent();
                    System.out.println("- " + nev + " | Tel: " + tel + " | Mail: " + mail);
                }
            }

            //3. lekérdezi azokat akik regisztráltak az "Innovációs Workshop"ra, listázza a konzolon
            System.out.println("\n3. Résztvevők, akik regisztráltak 'Innovációs Workshop'-ra:");
            NodeList regisztraciok = doc.getElementsByTagName("regisztracio");
            for (int i = 0; i < regisztraciok.getLength(); i++) {
                Element reg = (Element) regisztraciok.item(i);
                String esemeny = reg.getElementsByTagName("esemeny").item(0).getTextContent();
                if (esemeny.equals("Innovációs Workshop")) {
                    String rtkod = reg.getAttribute("kp_rt_rt");
                    NodeList resztvevok = doc.getElementsByTagName("resztvevo");
                    for (int j = 0; j < resztvevok.getLength(); j++) {
                        Element rt = (Element) resztvevok.item(j);
                        if (rt.getAttribute("rtkod").equals(rtkod)) {
                            String nev = rt.getElementsByTagName("nev").item(0).getTextContent();
                            System.out.println("- " + nev);
                        }
                    }
                }
            }

            //4. lekérdezés: angolul beszélő szervezők (és ahol dolgoznak), kilistázza konzolra
            System.out.println("\n4. Angolul beszélő szervezők (munkahelyük):");
            NodeList szervezok = doc.getElementsByTagName("szervezo");
            for (int i = 0; i < szervezok.getLength(); i++) {
                Element sz = (Element) szervezok.item(i);
                NodeList nyelvek = sz.getElementsByTagName("nyelv");
                boolean tudAngolul = false;
                for (int j = 0; j < nyelvek.getLength(); j++) {
                    if (nyelvek.item(j).getTextContent().equals("angol")) {
                        tudAngolul = true;
                        break;
                    }
                }
                if (tudAngolul) {
                    String nev = sz.getElementsByTagName("nev").item(0).getTextContent();
                    String kp_sz = sz.getAttribute("kp_sz");
                    NodeList kozpontok = doc.getElementsByTagName("kozpont");
                    for (int k = 0; k < kozpontok.getLength(); k++) {
                        Element kp = (Element) kozpontok.item(k);
                        if (kp.getAttribute("kpkod").equals(kp_sz)) {
                            String kpnev = kp.getElementsByTagName("nev").item(0).getTextContent();
                            System.out.println("- " + nev + " (Központ: " + kpnev + ")");
                        }
                    }
                }
            }

            // 5. Lekérdezés: "Kutatás" területen dolgozó résztvevők, kilistázása konzolra (lakóhelyükkel együtt)
            System.out.println("\n5. Résztvevők neve és lakóhelye, akik 'kutatás' területen dolgoznak:");
            NodeList resztvevok = doc.getElementsByTagName("resztvevo");
            for (int i = 0; i < resztvevok.getLength(); i++) {
                Element rt = (Element) resztvevok.item(i);
                String munkaterulet = rt.getElementsByTagName("munkaterulet").item(0).getTextContent();
                if (munkaterulet.toLowerCase().contains("kutatás")) {
                    String nev = rt.getElementsByTagName("nev").item(0).getTextContent();
                    String varos = ((Element) rt.getElementsByTagName("cim").item(0)).getElementsByTagName("varos").item(0).getTextContent();
                    System.out.println("- " + nev + " (" + varos + ")");
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
