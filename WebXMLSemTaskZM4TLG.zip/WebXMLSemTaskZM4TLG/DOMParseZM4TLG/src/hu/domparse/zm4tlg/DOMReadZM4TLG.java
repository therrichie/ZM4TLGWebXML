package hu.domparse.zm4tlg;

//Fájlkezeléshez és íráshoz szükséges 
import java.io.File;   // XML fájl objektumként való kezelése
import java.io.IOException;  // Fájlműveletek közben fellépő hibák kezelése
import java.io.BufferedWriter;  // soronkénti fájlba írás
import java.io.FileWriter;   // fájl megnyitása írásra

//DOM XML feldolgozáshoz szükséges importok 
import javax.xml.parsers.DocumentBuilder;  // DOM dokumentum építő
import javax.xml.parsers.DocumentBuilderFactory;  // DOM builder létrehozása
import javax.xml.parsers.ParserConfigurationException; // Parser hibakezelés

//DOM objektummodell osztályok
import org.w3c.dom.*;    // DOM objektumok és XML feldolgozáshoz kell (Element, Node, NodeList, stb.)

//XML fájl hibakezeléshez 
import org.xml.sax.SAXException;  // XML fájl szintaktikai hibáinak kezelése


public class DOMReadZM4TLG {

    public static void main(String[] args) throws SAXException, IOException, ParserConfigurationException {

        // Kimeneti fájl megnyitása írásra
        BufferedWriter writer = new BufferedWriter(new FileWriter("TXTKimenetZM4TLG.txt"));

        // XML fájl betöltése, objektumként való kezelése
        File xmlFile = new File("XMLZM4TLG.xml");
        
        // DOM feldolgozó létrehozása
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = factory.newDocumentBuilder();
        
        //xml fájl beolvasása DOM objektummá
        Document doc = dBuilder.parse(xmlFile);
        // DOM struktúra normalizálása (pl:felesleges whitespacek,üresnode-ok eltávolítása)
        doc.getDocumentElement().normalize();

        // Gyökérelem kiíratás
        System.out.println("Gyökér elem: " + doc.getDocumentElement().getNodeName());
        writer.write("Gyökér elem: " + doc.getDocumentElement().getNodeName() + "\n");
        
        // KÖZPONT feldolgozása
        NodeList kozpontok = doc.getElementsByTagName("kozpont"); //összes <kozpont> elem kigyűjtése

        for (int i = 0; i < kozpontok.getLength(); i++) {
            Node nNode = kozpontok.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) { // csak ha tényleges XML elem
                Element elem = (Element) nNode; // átalakítás Element típusra

                // Attribútum kiolvasása
                String kpkod = elem.getAttribute("kpkod");
                // Gyermekelemek kiolvasása
                String nev = elem.getElementsByTagName("nev").item(0).getTextContent();
                // Beágyazott <cim> feldolgozása
                Element cim = (Element) elem.getElementsByTagName("cim").item(0);
                String varos = cim.getElementsByTagName("varos").item(0).getTextContent();
                String utca = cim.getElementsByTagName("utca").item(0).getTextContent();
                String hazszam = cim.getElementsByTagName("hazszam").item(0).getTextContent();
                // Több kategória összegyűjtése
                NodeList kategoriak = ((Element) elem.getElementsByTagName("kategoriak").item(0)).getElementsByTagName("kategoria");
                StringBuilder kategoriaLista = new StringBuilder();
                for (int j = 0; j < kategoriak.getLength(); j++) {
                    kategoriaLista.append(kategoriak.item(j).getTextContent());
                    if (j < kategoriak.getLength() - 1) kategoriaLista.append(", ");
                }

                // Kiírás konzolra (blokkosítva formázva)
                System.out.println("\nKözpont ID: " + kpkod);
                System.out.println("Név: " + nev);
                System.out.println("Cím: " + varos + ", " + utca + " " + hazszam);
                System.out.println("Kategóriák: " + kategoriaLista);

                // Kiírás fájlba ugyanúgy
                writer.write("\nKözpont ID: " + kpkod + "\n");
                writer.write("Név: " + nev + "\n");
                writer.write("Cím: " + varos + ", " + utca + " " + hazszam + "\n");
                writer.write("Kategóriák: " + kategoriaLista + "\n");
            }
        }

        // FŐSZERVEZŐ feldolgozása    
        //  hasonlóan mint az előző KÖZPONT feldolgozásál és így tovább majd:szervezo, technikus,resztvevo...
        NodeList fszLista = doc.getElementsByTagName("foszervezo");

        for (int i = 0; i < fszLista.getLength(); i++) {
            Node nNode = fszLista.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element elem = (Element) nNode;

                String fszkod = elem.getAttribute("fszkod");
                String kp_fsz = elem.getAttribute("kp_fsz");
                String nev = elem.getElementsByTagName("nev").item(0).getTextContent();

                Element kontakt = (Element) elem.getElementsByTagName("kontakt").item(0);
                String email = kontakt.getElementsByTagName("mail").item(0).getTextContent();
                String tel = kontakt.getElementsByTagName("tel").item(0).getTextContent();

                NodeList vegzettsegek = elem.getElementsByTagName("vegzettseg");
                NodeList nyelvek = elem.getElementsByTagName("nyelv");

                StringBuilder vegzettsegLista = new StringBuilder();
                for (int j = 0; j < vegzettsegek.getLength(); j++) {
                    vegzettsegLista.append(vegzettsegek.item(j).getTextContent());
                    if (j < vegzettsegek.getLength() - 1) vegzettsegLista.append(", ");
                }

                StringBuilder nyelvLista = new StringBuilder();
                for (int j = 0; j < nyelvek.getLength(); j++) {
                    nyelvLista.append(nyelvek.item(j).getTextContent());
                    if (j < nyelvek.getLength() - 1) nyelvLista.append(", ");
                }

                System.out.println("\nFőszervező ID: " + fszkod);
                System.out.println("Központ kód: " + kp_fsz);
                System.out.println("Név: " + nev);
                System.out.println("Email: " + email + ", Tel: " + tel);
                System.out.println("Végzettségek: " + vegzettsegLista);
                System.out.println("Nyelvek: " + nyelvLista);

                writer.write("\nFőszervező ID: " + fszkod + "\n");
                writer.write("Központ kód: " + kp_fsz + "\n");
                writer.write("Név: " + nev + "\n");
                writer.write("Email: " + email + ", Tel: " + tel + "\n");
                writer.write("Végzettségek: " + vegzettsegLista + "\n");
                writer.write("Nyelvek: " + nyelvLista + "\n");
            }
        }
        
        // SZERVEZŐ feldolgozása 
        NodeList szervezok = doc.getElementsByTagName("szervezo");

        for (int i = 0; i < szervezok.getLength(); i++) {
            Node nNode = szervezok.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element elem = (Element) nNode;

                String szk = elem.getAttribute("szkod");
                String kp_sz = elem.getAttribute("kp_sz");
                String nev = elem.getElementsByTagName("nev").item(0).getTextContent();

                Element kontakt = (Element) elem.getElementsByTagName("kontakt").item(0);
                String email = kontakt.getElementsByTagName("mail").item(0).getTextContent();
                String tel = kontakt.getElementsByTagName("tel").item(0).getTextContent();

                String szakterulet = elem.getElementsByTagName("szakterulet").item(0).getTextContent();

                NodeList vegzettsegek = elem.getElementsByTagName("vegzettseg");
                NodeList nyelvek = elem.getElementsByTagName("nyelv");

                StringBuilder vegzettsegLista = new StringBuilder();
                for (int j = 0; j < vegzettsegek.getLength(); j++) {
                    vegzettsegLista.append(vegzettsegek.item(j).getTextContent());
                    if (j < vegzettsegek.getLength() - 1) vegzettsegLista.append(", ");
                }

                StringBuilder nyelvLista = new StringBuilder();
                for (int j = 0; j < nyelvek.getLength(); j++) {
                    nyelvLista.append(nyelvek.item(j).getTextContent());
                    if (j < nyelvek.getLength() - 1) nyelvLista.append(", ");
                }

                System.out.println("\nSzervező ID: " + szk);
                System.out.println("Központ kód: " + kp_sz);
                System.out.println("Név: " + nev);
                System.out.println("Email: " + email + ", Tel: " + tel);
                System.out.println("Szakterület: " + szakterulet);
                System.out.println("Végzettségek: " + vegzettsegLista);
                System.out.println("Nyelvek: " + nyelvLista);

                writer.write("\nSzervező ID: " + szk + "\n");
                writer.write("Központ kód: " + kp_sz + "\n");
                writer.write("Név: " + nev + "\n");
                writer.write("Email: " + email + ", Tel: " + tel + "\n");
                writer.write("Szakterület: " + szakterulet + "\n");
                writer.write("Végzettségek: " + vegzettsegLista + "\n");
                writer.write("Nyelvek: " + nyelvLista + "\n");
            }
        }

        // TECHNIKUS feldolgozása 
        NodeList technikusok = doc.getElementsByTagName("technikus");

        for (int i = 0; i < technikusok.getLength(); i++) {
            Node nNode = technikusok.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element elem = (Element) nNode;

                String tkod = elem.getAttribute("tkod");
                String kp_t = elem.getAttribute("kp_t");
                String nev = elem.getElementsByTagName("nev").item(0).getTextContent();

                Element kontakt = (Element) elem.getElementsByTagName("kontakt").item(0);
                String email = kontakt.getElementsByTagName("mail").item(0).getTextContent();
                String tel = kontakt.getElementsByTagName("tel").item(0).getTextContent();

                NodeList eszkList = elem.getElementsByTagName("eszkozismeret");
                NodeList vegzettsegek = elem.getElementsByTagName("vegzettseg");
                NodeList nyelvek = elem.getElementsByTagName("nyelv");

                StringBuilder eszkok = new StringBuilder();
                for (int j = 0; j < eszkList.getLength(); j++) {
                    eszkok.append(eszkList.item(j).getTextContent());
                    if (j < eszkList.getLength() - 1) eszkok.append(", ");
                }

                StringBuilder vegzettsegLista = new StringBuilder();
                for (int j = 0; j < vegzettsegek.getLength(); j++) {
                    vegzettsegLista.append(vegzettsegek.item(j).getTextContent());
                    if (j < vegzettsegek.getLength() - 1) vegzettsegLista.append(", ");
                }

                StringBuilder nyelvLista = new StringBuilder();
                for (int j = 0; j < nyelvek.getLength(); j++) {
                    nyelvLista.append(nyelvek.item(j).getTextContent());
                    if (j < nyelvek.getLength() - 1) nyelvLista.append(", ");
                }

                System.out.println("\nTechnikus ID: " + tkod);
                System.out.println("Központ kód: " + kp_t);
                System.out.println("Név: " + nev);
                System.out.println("Email: " + email + ", Tel: " + tel);
                System.out.println("Eszközismeret: " + eszkok);
                System.out.println("Végzettségek: " + vegzettsegLista);
                System.out.println("Nyelvek: " + nyelvLista);

                writer.write("\nTechnikus ID: " + tkod + "\n");
                writer.write("Központ kód: " + kp_t + "\n");
                writer.write("Név: " + nev + "\n");
                writer.write("Email: " + email + ", Tel: " + tel + "\n");
                writer.write("Eszközismeret: " + eszkok + "\n");
                writer.write("Végzettségek: " + vegzettsegLista + "\n");
                writer.write("Nyelvek: " + nyelvLista + "\n");
            }
        }

        // RÉSZTVEVŐ feldolgozása 
        NodeList resztvevok = doc.getElementsByTagName("resztvevo");

        for (int i = 0; i < resztvevok.getLength(); i++) {
            Node nNode = resztvevok.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element elem = (Element) nNode;

                String rtkod = elem.getAttribute("rtkod");
                String nev = elem.getElementsByTagName("nev").item(0).getTextContent();
                String munkaterulet = elem.getElementsByTagName("munkaterulet").item(0).getTextContent();
                String email = elem.getElementsByTagName("mail").item(0).getTextContent();

                Element cim = (Element) elem.getElementsByTagName("cim").item(0);
                String varos = cim.getElementsByTagName("varos").item(0).getTextContent();
                String utca = cim.getElementsByTagName("utca").item(0).getTextContent();
                String hazszam = cim.getElementsByTagName("hazszam").item(0).getTextContent();

                System.out.println("\nRésztvevő ID: " + rtkod);
                System.out.println("Név: " + nev);
                System.out.println("Munkaterület: " + munkaterulet);
                System.out.println("Email: " + email);
                System.out.println("Cím: " + varos + ", " + utca + " " + hazszam);

                writer.write("\nRésztvevő ID: " + rtkod + "\n");
                writer.write("Név: " + nev + "\n");
                writer.write("Munkaterület: " + munkaterulet + "\n");
                writer.write("Email: " + email + "\n");
                writer.write("Cím: " + varos + ", " + utca + " " + hazszam + "\n");
            }
        }

        // REGISZTRÁCIÓ feldolgozása 
        NodeList regisztraciok = doc.getElementsByTagName("regisztracio");

        for (int i = 0; i < regisztraciok.getLength(); i++) {
            Node nNode = regisztraciok.item(i);

            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element elem = (Element) nNode;

                String kp_rt_kp = elem.getAttribute("kp_rt_kp");
                String kp_rt_rt = elem.getAttribute("kp_rt_rt");

                String osszeg = elem.getElementsByTagName("osszeg").item(0).getTextContent();
                String esemeny = elem.getElementsByTagName("esemeny").item(0).getTextContent();

                System.out.println("\nRegisztráció:\nA  " + kp_rt_kp + " azonosítójú központba regisztrált az " + kp_rt_rt + " azonosítójú résztvevő");
                System.out.println("Összeg: " + osszeg);
                System.out.println("Esemény: " + esemeny);

                writer.write("\nRegisztráció:\nA  " + kp_rt_kp + " azonosítójú központba regisztrált az " + kp_rt_rt + " azonosítójú résztvevő\n");
                writer.write("Összeg: " + osszeg + "\n");
                writer.write("Esemény: " + esemeny + "\n");
            }
        }

        // író bezárása
        writer.close();
    }
}


        