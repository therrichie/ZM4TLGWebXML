/**
 * 
 */
/**
 * 
 */
module DOM_parse_bead {
	requires java.xml;
}